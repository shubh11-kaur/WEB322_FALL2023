const setData = require("../data/setData");
const themeData = require("../data/themeData");


let sets = [];

function Initialize(){

    return new Promise((resolve) => {
        setData.forEach((element) => {
          let { theme_id } = element;
    
          themeobj = themeData.find((theme) => theme_id == theme.id);
          element.theme = themeobj.name;
          sets.push(element);
        });
    
        resolve(); // Resolve the Promise with no data when the operation is complete
      });

}

function getAllSets(){

    return new Promise((resolve)=>{

        resolve(sets)

    })
    
}

function getSetByNum(setNum){
    return new Promise((resolve, reject) => {
        let numSet = sets.find((element) => setNum === element.set_num);
        
        if (numSet !== undefined) {
          resolve(numSet);
        } else {
          reject(new Error("Failed to fetch data"));
        }
      });
    
    
}

function getSetsByTheme(themets){

    return new Promise((resolve, reject) => {

        themets = themets.toUpperCase();
        let setTheme = sets.filter(element=>element.theme.toUpperCase().includes(themets.toUpperCase()))

        if (setTheme.length !== 0) {
            resolve(setTheme);
          } else {
            reject(new Error("Failed to fetch data"));
          }

    })

}

module.exports = { Initialize, getAllSets, getSetByNum, getSetsByTheme }




