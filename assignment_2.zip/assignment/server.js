/********************************************************************************
* WEB322 – Assignment 02
*
* I declare that this assignment is my own work in accordance with Seneca's
* Academic Integrity Policy:
*
* https://www.senecacollege.ca/about/policies/academic-integrity-policy.html
*
* Name: __shubhdeep kaur____________________ Student ID: ____172915217__________ Date: _______14thoct2023_______
*
********************************************************************************/

const express = require('express');
const app = express();
const legoData = require("./modules/legoSets");
const port = 3000;

console.log(legoData.Initialize());

app.get('/', (req, res) => {
    res.send('Assignment 2: Avreet Kaur, is - ');
  });

app.get('/lego/sets', (req, res) => {
    legoData.getAllSets().then(data=>res.json(data));
  });

app.get('/lego/sets/num-demo', (req, res) => {


    legoData.getSetByNum('001-1').then(data=>res.json(data)).catch(error=>console.log(error));
  });

app.get('/lego/sets/theme-demo', (req, res) => {


    legoData.getSetsByTheme('Technic').then(data=>res.json(data)).catch(error=>console.log(error));;
  });



app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
  });



  