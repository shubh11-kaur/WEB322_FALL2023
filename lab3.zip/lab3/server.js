const express = require('express');
const app = express();
const cors = require('cors');

app.use(cors());
const PORT = 3000;

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

const cars = [
    { id: 1, brand: 'Toyota', model: 'Corolla', year: 2020 },
    { id: 2, brand: 'Honda', model: 'Civic', year: 2019 },
    { id: 3, brand: 'Ford', model: 'Mustang', year: 2018 },
    { id: 4, brand: 'Chevrolet', model: 'Camaro', year: 2021 },
    { id: 5, brand: 'Tesla', model: 'Model S', year: 2020 }
  ];

  app.get('/cars', (req, res) => {
    res.json(cars);
  });
  