function fetchCars() {
  console.log("fetching cars.....")
    fetch('http://localhost:3000/cars')
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(data => displayCars(data))
      .catch(error => console.error('Error:', error));
  }
  
  function displayCars(data) {
    const carList = document.getElementById('carList');
    carList.innerHTML = '';
  
    data.forEach(car => {
      const carInfo = document.createElement('div');
      carInfo.innerHTML = `<strong>${car.brand} ${car.model}</strong> (${car.year})<br>`;
      carList.appendChild(carInfo);
    });
  }
  
  document.querySelector('button').addEventListener('click', fetchCars);
  
  function fetchCars() {
    fetch('http://localhost:3000/cars')
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(data => displayCars(data))
      .catch(error => console.error('Error:', error));
  }
  