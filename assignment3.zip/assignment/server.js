/********************************************************************************
* WEB322 – Assignment 03
*
* I declare that this assignment is my own work in accordance with Seneca's
* Academic Integrity Policy:
*
* hRps://www.senecacollege.ca/about/policies/academic-integrity-policy.html
*
* Name: ___Shubhdeep Kaur___________________ Student ID: _172915217_____________ Date: ____30thoct2023__________
*
* Published URL: https://fantastic-visor-worm.cyclic.app/
* Github URL: https://github.com/shubh-kaur11/web3Assignment/
*
********************************************************************************/

const express = require('express');
const path = require('path');
const app = express();
const legoData = require("./modules/legoSets");
const port = 3000;

console.log(legoData.Initialize());

app.use(express.static('public')); 

app.get('/', (req, res) => {
    const filePath = path.join(__dirname,'public', 'views', 'home.html');
    res.sendFile(filePath);
  });

  app.get('/about', (req, res) => {
    const filePath = path.join(__dirname,'public', 'views', 'about.html');
    res.sendFile(filePath);
  });



app.get('/lego/sets', (req, res) => {
    obj_len = Object.keys(req.query).length;
    if(obj_len===0){legoData.getAllSets().then(data=>res.json(data));}
    else{
      console.log(req.query.theme)
      legoData.getSetsByTheme(req.query.theme).then(data=>res.json(data)).catch(error=>console.log(error));
    }
    
  });

app.get('/lego/sets/:numdemo', (req, res) => {
  const filePath = path.join(__dirname,'public', 'views', '404.html');

    numdemo=req.params.numdemo;
    legoData.getSetByNum(numdemo).then(data=>res.json(data)).catch(error=>res.sendFile(filePath));
  });

// app.get('/lego/sets/theme-demo', (req, res) => {


//     legoData.getSetsByTheme('RoboRiders').then(data=>res.json(data)).catch(error=>console.log(error));;
//   });

app.use((req, res) => {
  const filePath = path.join(__dirname,'public', 'views', '404.html');
  res.status(404).sendFile(filePath);
});


  


app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
  });



  