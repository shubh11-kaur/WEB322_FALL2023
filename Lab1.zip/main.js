//main.js

const calculateSum = require('./lab1');

async function main() {
  try {
    const sum = await calculateSum([1, 2, 3], 1000);
    console.log('Sum:', sum);
  } catch (error) {
    console.error('Error:', error);
  }
}

main();
