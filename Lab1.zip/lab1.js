//lab1.js

function calculateSum(numbers, delay) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const sum = numbers.reduce((acc, num) => acc + num, 0);
      resolve(sum);
    }, delay);
  });
}

module.exports = calculateSum;

