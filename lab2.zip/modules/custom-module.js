module.exports = {
    greeting: "Custom Greeting Message"
  };
  