const customModule = require('./modules/custom-module');
const greetingMessage = customModule.greeting;

const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => {
   // Replace placeholder with custom greeting
   const customGreeting = 'Welcome to our website!';
   res.send(`<h1>${customGreeting}</h1>`);
});

app.use(express.static('public'));

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});


