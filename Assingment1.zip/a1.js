/*********************************************************************************
* WEB322 – Assignment 1
* I declare that this assignment is my own work in accordance with Seneca Academic Policy.
* No part of this assignment has been copied manually or electronically from any other source
* (including web sites) or distributed to other students.
*
* Name: ____Shubhdeep Kaur__________________ Student ID: ____172915217______________ Date: _________29thsep2023___________
*
********************************************************************************/ 


const fs = require('fs');
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Step 2: User Input

rl.question("Do you wish to process a File (f) or directory (d): ", (choice) => {
  if (choice === 'f') {
    rl.question("Enter the file name to analyze: ", (fileName) => {
      console.log(`File: ${fileName}`);

      // Step 3: Processing the File

      analyzeFile(fileName);
      rl.close();
    });
  } 
  
  else if (choice === 'd') {
    rl.question("Enter the directory name to analyze: ", (dirName) => {
      console.log(`Directory: ${dirName}`);
      
      rl.close();
    });
  } 
  
  else {
    console.log("Invalid Selection");
    rl.close();
  }
});

// Step 3: Processing the File

function analyzeFile(fileName) {
  fs.readFile(fileName, 'utf8', (err, data) => {
    if (err) {
      console.log(err.message);  // error message if file cannot be read
    } 
    
    else {
      
      const cleanedText = data.toString().replace(/\s+/g, ' '); //removing spaces

      const words = cleanedText.replace(/[^\w\s\']/g, "").split(' ');

      
      const numCharacters = cleanedText.length;   //characters
      const numWords = words.length;
      const longestWord = words.reduce((longest, word) => {
        return word.length > longest.length ? word : longest;
      }, '');



      console.log(`Number of Characters (including spaces): ${numCharacters}`);
      console.log(`Number of Words: ${numWords}`);
      console.log(`Longest Word: ${longestWord}`);
    }

  });
}

// Step 4: Processing the Directory

function analyzeDirectory(dirName) {
    fs.readdir(dirName, (err, files) => {
      if (err) {
        console.log(err.message); 
      } else {
         const sortedFiles = files.sort((a, b) => b.localeCompare(a));
        console.log(`Files (reverse alphabetical order): ${sortedFiles.join(', ')}`);
      }
    });


  }